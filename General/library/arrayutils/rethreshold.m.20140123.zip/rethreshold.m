function [nsdata, nsheader] = rethreshold(nsfilename,varargin)
% rethreshold(filename,threshold,filtervalues,...)

% define default values
threshold   = -5; % -5 std
low_cutoff  = 200;
high_cutoff = 3000;
%lags        = -20:60;
lags        = -12:12; % search for minima/maxima within a +/- .4 ms window.
pnamestr    = '/experiments/m%s_array/recordings/%s';

logname     = '/tmp/%s.log';


%% VALIDATION OF INPUTS
[pname,fname,ext] = fileparts(nsfilename); % get path, name, extension

logfilename = sprintf(logname,fname);
flog = fopen(logfilename,'w');
if flog==-1
    error('rethreshold:logcreation','Couldn''t create log file in /tmp');
end
switch ext
    case '.ns6' % found raw
        filetype = 'ns6';
     case '.ns2' % found lfp data (already filtered)
         filetype = 'ns2';
         low_cutoff  = nan;
         high_cutoff = nan;
         fprintf(flog,'Data is already filtered for LFPs.\n');
    otherwise
        error('rethreshold:filevalid','The following file is of unknown type: %s',nsfilename);
end
if isempty(pname)
    monkeyid = fname(2:4);
    pname = sprintf(pnamestr,monkeyid,filetype);
end



nsfilename = [pname filesep fname ext];

if ~exist(nsfilename,'file') % if the file exists
    error('rethreshold:file_exists_check','The following file was not found: %s',nsfilename);
end

if ~mod(nargin,2)
    error('rethreshold:paramerror','Incorrect number of parameters given');
else
    for ii=2:2:nargin
        param = varargin{ii-1};
        value = varargin{ii};
        switch param
            case 'threshold'
                threshold = value;
            case 'bandpass'
                if numel(value) ~= 2
                    error('rethreshold:paramerror','Incorrect number of frequency bands. You supplied %d value(s) instead of 2.',numel(value));
                end
                low_cutoff  = value(1);
                high_cutoff = value(2);
            case 'lowpass'
                if numel(value) ~= 1
                    error('rethreshold:paramerror','Incorrect number of frequency bands. You supplied %d value(s) instead of 1.',numel(value));
                end
                low_cutoff  = nan;
                high_cutoff = value(1);
            case 'highpass'
                if numel(value) ~= 1
                    error('rethreshold:paramerror','Incorrect number of frequency bands. You supplied %d value(s) instead of 1.',numel(value));
                end
                low_cutoff  = value(1);
                high_cutoff = nan;
            otherwise
                error('rethreshold:paramerror','Unknown parameter: %s',param);
        end
    end
end

fprintf(flog,[...
    'Processing file: %s\n'...
    'with the following settings:\n'],...
    nsfilename);

if all(isnan([low_cutoff high_cutoff]))
    error('rethreshold:filtercutoffcheck','Both high and low pass cutoffs are nan!\n');
elseif isnan(low_cutoff)
    fprintf(flog,'Lowpass Filter: 0 Hz to %.1f Hz\n',high_cutoff);
elseif isnan(high_cutoff)
    fprintf(flog,'Highpass Filter: %.1f Hz to Nyquist\n',low_cutoff);
else
    fprintf(flog,'Bandpass Filter: %.1f Hz to %.1f Hz\n',low_cutoff,high_cutoff);
end

fprintf(flog,'Threshold: %.1f std\n',threshold);

%% PROCESSING FILE

[nsdata,nsheader] = getNSxData(nsfilename);

nsheader.filename = nsfilename;
%%

if isnan(low_cutoff)
    [b,a]=butter(4,high_cutoff./(nsheader.SamplingFreq/2),'low');
elseif isnan(high_cutoff)
    [b,a]=butter(4,low_cutoff./(nsheader.SamplingFreq/2),'high');
else
    [b,a]=butter(4,[low_cutoff high_cutoff]./(nsheader.SamplingFreq/2));
end
%%
nsdata.snippets   = cell(nsheader.ChannelCount,1);
nsdata.timestamps = cell(nsheader.ChannelCount,1);
%%
bb=tic;
for segment = 1: nsdata.segments
    for curchannel = 1: nsheader.ChannelCount        
        aa=tic;
        fprintf(flog,'Channel %02d:',curchannel);
        voltage     = cat(2,zeros(1,nsdata.TimeStamps(segment)),(double(nsdata.raw{segment}(curchannel,:))),zeros(1,60));        
        nsheader.ElectrodesInfo(curchannel).HighFreqCorner = low_cutoff*1000;
        nsheader.ElectrodesInfo(curchannel).HighFreqOrder  = 4;
        nsheader.ElectrodesInfo(curchannel).HighFreqType   = 1;
        nsheader.ElectrodesInfo(curchannel).LowFreqCorner  = high_cutoff*1000;
        nsheader.ElectrodesInfo(curchannel).LowFreqOrder   = 4;
        nsheader.ElectrodesInfo(curchannel).LowFreqType    = 1;        
        % ------------------------------------------------------------------
        if curchannel==97
            fprintf(flog,' [~FILTERING]');
        else
            fprintf(flog,' [FILTERING]');
            voltage    = FiltFiltM(b,a,voltage);            
        end
        % ------------------------------------------------------------------
        fprintf(flog,'[STD]');
        voltagestd  = std(voltage,0,2);
        % ------------------------------------------------------------------
        if curchannel==97
            fprintf(flog,'[THRESH @ %.1f STD]',1);
            nsheader.ElectrodesInfo(curchannel).HighThreshold = voltagestd;
            nsheader.ElectrodesInfo(curchannel).LowThreshold  = 0;
            ndxs = find(voltage>voltagestd);            
        else
            fprintf(flog,'[THRESH @ %.1f STD]',threshold);
            switch sign(threshold)
                case -1
                    nsheader.ElectrodesInfo(curchannel).HighThreshold = 0;
                    nsheader.ElectrodesInfo(curchannel).LowThreshold  = voltagestd*threshold;
                    ndxs = find((voltage)<(voltagestd*threshold));
                case 1
                    nsheader.ElectrodesInfo(curchannel).HighThreshold = voltagestd*threshold;
                    nsheader.ElectrodesInfo(curchannel).LowThreshold  = 0;
                    ndxs = find((voltage)>(voltagestd*threshold));
            end
        end
        if ~isempty(ndxs)
            ndxs = ndxs([true diff(ndxs)>6])'; % force spikes to be at least 0.2 ms / 6 samples apart
            ndxs(ndxs<20) = [];
            ndxs(ndxs>(size(voltage,2)-61)) = [];
        end
        % ------------------------------------------------------------------
        fprintf(flog,'[WAVEFORMS]');
        if ~isempty(ndxs)
            nsnippets = size(ndxs,1);
        else
            nsnippets = 0;
        end
        snippets = zeros(nsnippets,size(lags,2));
        for ii=1:nsnippets
            snippets(ii,:) = voltage(1,ndxs(ii)+(lags));
        end
        % ------------------------------------------------------------------
        fprintf(flog,'[ALIGNING]');
        if nsnippets>0
            if (curchannel == 97)
                [~,lag] = max(snippets,[],2);
            else
                switch sign(threshold)
                    case -1
                        [~,lag]=min(snippets,[],2);
                    case 1
                        [~,lag]=max(snippets,[],2);
                end
            end
            laglist = lags(lag)';
            ndxs = ndxs + laglist;
            ndxs = unique(ndxs);
            snippets = zeros(size(ndxs,1),48);
            for ii=1:size(snippets,1)
                snippets(ii,:) = voltage(1,ndxs(ii)+(-9:38));
            end
        end
        nsdata.timestamps{curchannel,1} = ndxs;
        nsdata.snippets{curchannel}     = snippets;
        fprintf(flog,'[%06d snippets] %.1f s\n',nsnippets,toc(aa));
    end
end
fprintf(flog,'---------------------------------\n%.1f s\n',toc(bb));
nsdata = rmfield(nsdata,'raw');
fclose(flog);
