function infiniteloop

% function infiniteloop
%
% do nothing forever.
%
% example:
% infiniteloop

while 1
  randn(100,100);
end
