function M = LoadArrayMapFile(mapFileName)
% LoadArrayMapFile(mapFileName)
% ex: mapFileName = 'array_01Aug02H-2.cmp';

fid = fopen(mapFileName);

[~,fileName,~] = fileparts(mapFileName);
if strcmp(fileName,'SN 4037-000048')
    hasElecLabels = 1;
    C = textscan(fid,'%d %d %s %d %s','HeaderLines',14);
else
    hasElecLabels = 0;
    C = textscan(fid,'%d %d %s %d','HeaderLines',3);
end
fclose(fid);

row = 1+double(C{1});
col = 1+double(C{2});
bank = cell2mat(C{3});
pin = double(C{4});

M.col = [];
M.row = [];
if hasElecLabels
    label = C{5};
    M.label = [];
end
nBanks = 3;
bankLetter = 'ABC';

for iB = 1:nBanks
    bindBank = bank==bankLetter(iB);
    pinMasked = pin.*bindBank;
    [pinMaskedSort,ind] = sort(pinMasked);
    
    M.col = [M.col ; col(ind(pinMaskedSort>0))];
    M.row = [M.row ; row(ind(pinMaskedSort>0))];
    if hasElecLabels
        M.label = [M.label ; label(ind(pinMaskedSort>0))];
    end
end

M.mapFileName = mapFileName;