function M = LoadArrayMapFile(mapFileName)
% mapFileName = 'array_01Aug02H-2.cmp';

fid = fopen(mapFileName);
    C = textscan(fid,'%d %d %s %d','HeaderLines',3);
fclose(fid);

row = 1+double(C{1});
col = 1+double(C{2});
bank = cell2mat(C{3});
pin = double(C{4});

M.col = [];
M.row = [];

nBanks = 3;
bankLetter = 'ABC';

for iB = 1:nBanks
    bindBank = bank==bankLetter(iB);
    pinMasked = pin.*bindBank;
    [pinMaskedSort,ind] = sort(pinMasked);
    
    M.col = [M.col ; col(ind(pinMaskedSort>0))];
    M.row = [M.row ; row(ind(pinMaskedSort>0))];
end

M.mapFileName = mapFileName;